<meta charset="utf-8">
<link href="{{asset('images/logo1.svg')}}" rel="shortcut icon">
<meta name="viewport" content="width=device-width, initial-scale=1">
{{-- <meta name="description" content="Enigma admin is super flexible, powerful, clean & modern responsive tailwind admin template with unlimited possibilities."> --}}
{{-- <meta name="keywords" content="admin template, Enigma Admin Template, dashboard template, flat admin template, responsive admin template, web app"> --}}
<meta name="author" content="LEFT4CODE">
<title>Dashboard - Firm Tech Services - CRM</title>
<!-- BEGIN: CSS Assets-->
<link rel="stylesheet" href="{{asset('css/app.css')}}" />
<link rel="stylesheet" href="https://cdn.datatables.net/1.13.1/cs s/dataTables.bootstrap5.min.css">
<link rel="stylesheet" href="https://cdn.datatables.net/1.13.1/css/jquery.dataTables.min.css">

