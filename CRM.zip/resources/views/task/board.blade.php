@extends('layouts.app')

@section('content')
    @include('vendor.filament-kanban.kanban-record')
@endsection
