

<?php $__env->startSection('title', __('Server Error')); ?>
<?php $__env->startSection('code', 'Login Again'); ?>
<?php $__env->startSection('message', __('Session Timeout')); ?>

<a style="float: right; margin: 20px; padding: 8px 20px; background-color: #0C5BCB; border-radius: 7px; color: #fff" href="<?php echo e(route('login')); ?>" class="btn btn-primary">Login</a>

<?php echo $__env->make('errors::minimal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\CRM\resources\views/errors/500.blade.php ENDPATH**/ ?>