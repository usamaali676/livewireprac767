<?php $__env->startSection('content'); ?>
<?php if(Auth::check()): ?>
<?php
// $mperm = App\Models\perm;
$users = Auth::user();
// $perm = App\Models\perm::where('role_id', $user->role_id)->where('name', "Roles")->first();
// $permsheet = App\Models\perm::where('role_id', $user->role_id)->where('name', "Sales")->first();
?>
<?php endif; ?>
        <!-- BEGIN: Content -->
        <div class="content content--top-nav">
            <div class="intro-y flex items-center mt-8">
                <h2 class="text-lg font-medium mr-auto">
                    Salary
                </h2>
                <a href="<?php echo e(route('salary.create')); ?>" class="btn btn-primary shadow-md mr-2">Generate Salary</a>
            </div>
                                <!-- BEGIN: Striped Rows -->
                                <div class="intro-y box mt-5">
                                    <div class="p-5" id="striped-rows-table">
                                        <div class="preview">
                                            <div class="overflow-x-auto">
                                                <table id="example" class="table table-report">
                                                    <thead>
                                                        <tr>
                                                            <th class="whitespace-nowrap">Sr.</th>
                                                            <th class="whitespace-nowrap">Name</th>
                                                            <th class="whitespace-nowrap">Dept</th>
                                                            <th class="whitespace-nowrap">Basic Salary</th>
                                                            <th class="whitespace-nowrap">Salary Mont</th>
                                                            <th class="whitespace-nowrap">Action</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <?php $__currentLoopData = $salary; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <tr>
                                                            <td><?php echo e($srno++); ?></td>
                                                            <td><?php echo e($item->user->name); ?></td>
                                                            <td><?php echo e($item->user->department->name); ?></td>
                                                            <td><?php echo e($item->basic_salary); ?></td>
                                                            <td><?php echo e($item->salary_month); ?></td>
                                                            <td><a class="btn btn-warning mr-1 mb-2" href="<?php echo e(route('salary.edit',$item->id)); ?>" > <i data-lucide="edit" style="color: #fff" class="w-5 h-5"></i> </a> <a href="<?php echo e(route('salary.detail', $item->id)); ?>" class="btn btn-success mr-1 mb-2"> <i data-lucide="eye" class="w-5 h-5" style="color: #fff"></i> </a><a href="<?php echo e(route('salary.conf-delete', $item->id)); ?>" class="btn btn-danger mr-1 mb-2"> <i data-lucide="trash" class="w-5 h-5"></i> </a> </td>
                                                        </tr>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <!-- END: Striped Rows -->
        </div>
        <!-- END: Content -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\CRM\resources\views/salary/index.blade.php ENDPATH**/ ?>