<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="grid grid-cols-12 gap-6">
    <div class="col-span-12 2xl:col-span-9">
        <div class="grid grid-cols-12 gap-6">
            <!-- BEGIN: General Report -->
            <div class="col-span-12 mt-8">
                <div class="intro-y flex items-center h-10">
                    <h2 class="text-lg font-medium truncate mr-5">
                        Dashboard
                    </h2>
                    <a href="" class="ml-auto flex items-center text-primary"> <i data-lucide="refresh-ccw" class="w-4 h-4 mr-3"></i> Reload Data </a>
                </div>
                <div class="grid grid-cols-12 gap-6 mt-5">
                    <div class="col-span-12 sm:col-span-6 xl:col-span-3 intro-y">
                        <div class="report-box zoom-in">
                            <div class="box p-5">
                                <div class="flex">
                                    <i data-lucide="shopping-cart" class="report-box__icon text-primary"></i>
                                    <div class="ml-auto">
                                    </div>
                                </div>

                                <div class="text-3xl font-medium leading-8 mt-6"><?php echo e($department); ?></div>

                                <div class="text-base text-slate-500 mt-1">Total Departments</div>
                            </div>
                        </div>
                    </div>
                    <div class="col-span-12 sm:col-span-6 xl:col-span-3 intro-y">
                        <div class="report-box zoom-in">
                            <div class="box p-5">
                                <div class="flex">
                                    <i data-lucide="credit-card" class="report-box__icon text-pending"></i>
                                    <div class="ml-auto">
                                        
                                    </div>
                                </div>
                                <div class="text-3xl font-medium leading-8 mt-6"><?php echo e($designation); ?></div>
                                <div class="text-base text-slate-500 mt-1">Total Dasignations</div>
                            </div>
                        </div>
                    </div>
                    <div class="col-span-12 sm:col-span-6 xl:col-span-3 intro-y">
                        <div class="report-box zoom-in">
                            <div class="box p-5">
                                <div class="flex">
                                    <i data-lucide="monitor" class="report-box__icon text-warning"></i>
                                    <div class="ml-auto">
                                        
                                    </div>
                                </div>
                                <div class="text-3xl font-medium leading-8 mt-6"><?php echo e($roles); ?></div>
                                <div class="text-base text-slate-500 mt-1">Total Roles</div>
                            </div>
                        </div>
                    </div>
                    <div class="col-span-12 sm:col-span-6 xl:col-span-3 intro-y">
                        <div class="report-box zoom-in">
                            <div class="box p-5">
                                <div class="flex">
                                    <i data-lucide="user" class="report-box__icon text-success"></i>
                                    <div class="ml-auto">
                                        
                                    </div>
                                </div>
                                <div class="text-3xl font-medium leading-8 mt-6"><?php echo e($all_user); ?></div>
                                <div class="text-base text-slate-500 mt-1">Total Users</div>
                            </div>
                        </div>
                    </div>
                </div>
                                            <!-- BEGIN: Sales Report -->
                                            
                                            <!-- END: Sales Report -->
            </div>




        </div>
    </div>
    <div class="col-span-12 2xl:col-span-3">
        <div class="2xl:border-l -mb-10 pb-10">
            <div class="2xl:pl-6 grid grid-cols-12 gap-x-6 2xl:gap-x-0 gap-y-6">
                <!-- BEGIN: Transactions -->
                <div class="col-span-12 md:col-span-6 xl:col-span-4 2xl:col-span-12 mt-3 2xl:mt-8">
                    <div class="intro-x flex items-center h-10">
                        <h2 class="text-lg font-medium truncate mr-5">
                            Online Users
                        </h2>
                    </div>
                    <div class="mt-5">
                        <div class="intro-x">
                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="box px-5 py-3 mb-3 flex items-center zoom-in">
                                    <div class="w-10 h-10 flex-none image-fit rounded-full overflow-hidden">
                                        <img alt="Midone - HTML Admin Template" src="<?php echo e(asset('images/profile-5.jpg')); ?>">
                                        <?php if(Cache::has('user-is-online-' . $item->id)): ?>
                                            <div class="w-3 h-3 bg-success absolute right-0 bottom-0 rounded-full border-2 border-white" style="right: 6px;"></div>
                                        <?php endif; ?>
                                    </div>
                                    <div class="ml-4 mr-auto">

                                        <div class="font-medium"><?php echo e($item->name); ?></div>
                                        <?php if(Cache::has('user-is-online-' . $item->id)): ?>
                                        <div class="text-slate-500 text-xs mt-0.5">Online</div>
                                        <?php else: ?>
                                        <div class="text-slate-500 text-xs mt-0.5"><?php echo e(Carbon\Carbon::parse($item->last_seen)->diffForHumans()); ?></div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        
                        <a href="<?php echo e(route('user.index')); ?>" class="intro-x w-full block text-center rounded-md py-3 border border-dotted border-slate-400 dark:border-darkmode-300 text-slate-500">View More</a>
                    </div>
                </div>
                <!-- END: Transactions -->
                <!-- BEGIN: Recent Activities -->
                
                <!-- END: Recent Activities -->
                <!-- BEGIN: Important Notes -->
                
                <!-- END: Important Notes -->
                <!-- BEGIN: Schedules -->
                
                <!-- END: Schedules -->
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\CRM\resources\views/home.blade.php ENDPATH**/ ?>