<?php $__env->startSection('content'); ?>
<?php if(Auth::check()): ?>
<?php
// $perm = App\Models\perm;
$user = Auth::user();
$perm = App\Models\perm::where('role_id', $user->role_id)->where('name', "clients")->first();
$permuser = App\Models\perm::where('role_id', $user->role_id)->where('name', "Users")->first();
$permreports = App\Models\perm::where('role_id', $user->role_id)->where('name', "reports")->first();
?>
<?php endif; ?>
        <!-- BEGIN: Content -->
        <div class="content content--top-nav">
            <div class="intro-y flex items-center mt-8">
                <h2 class="text-lg font-medium mr-auto">
                    Clients
                </h2>
               
               
               
            </div>
                                <!-- BEGIN: Striped Rows -->
                                <div class="intro-y box mt-5">
                                    <div class="p-5" id="striped-rows-table">
                                        <div class="preview">
                                            <div class="overflow-x-auto">
                                                <table id="example" class="table table-report">
                                                    <thead>
                                                        <tr>
                                                            <th class="whitespace-nowrap">Sr.</th>
                                                            <th class="whitespace-nowrap">Name</th>
                                                            <th class="whitespace-nowrap">Start Date</th>
                                                            
                                                            <th class="whitespace-nowrap">Services</th>
                                                            <th class="whitespace-nowrap">Action</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <?php $__currentLoopData = $client; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <tr>
                                                            <td><?php echo e($srno++); ?></td>
                                                            <td><?php echo e($item->sale->business_name); ?></td>
                                                            <td><?php echo e($item->start_date); ?></td>
                                                            
                                                            <td>
                                                            <?php $__currentLoopData = $item->services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <span style="background: #0C5BCB; padding: 10px; color: #fff; border-radius: 5px "><?php echo e($service->name); ?></span>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></td>

                                                             <td>
                                                                <?php if($perm->edit == 1 ): ?>
                                                                <a class="btn btn-warning mr-1 mb-2" href="<?php echo e(route('clients.edit',$item->id)); ?>" > <i data-lucide="edit" style="color: #fff" class="w-5 h-5"></i> </a>
                                                                <?php endif; ?>
                                                                <?php if($perm->view == 1): ?>
                                                                <a href="<?php echo e(route('clients.detail', $item->id)); ?>" class="btn btn-success mr-1 mb-2"> <i data-lucide="eye" class="w-5 h-5" style="color: #fff"></i> </a>
                                                                <?php endif; ?>
                                                                <?php if($perm->delete == 1  ): ?>
                                                                <a  href="<?php echo e(route('clients.conf-delete', $item->id)); ?>"  class="btn btn-danger mr-1 mb-2"> <i data-lucide="trash" class="w-5 h-5"></i> </a>
                                                                <?php endif; ?>
                                                                <?php if($permreports->view == 1): ?>
                                                                    <a  href="<?php echo e(route('reports.index', $item->id)); ?>"  class="btn btn-primary mr-1 mb-2"> <i data-lucide="clipboard" class="w-5 h-5"></i> </a>
                                                                <?php endif; ?>
                                                            </td>
                                                        </tr>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <!-- END: Striped Rows -->
        </div>
        <!-- END: Content -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\CRM\resources\views/client/index.blade.php ENDPATH**/ ?>