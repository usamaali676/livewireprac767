<?php $__env->startSection('css'); ?>
<script src="https://cdn.ckeditor.com/4.22.1/standard/ckeditor.js"></script>
<style>
    div#cke_notifications_area_editor1, div#cke_notifications_area_editor2 {
    display: none;
}
</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <!-- BEGIN: Content -->
    <div class="content content--top-nav">
        <div class="intro-y flex items-center mt-8">
            <h2 class="text-lg font-medium mr-auto">
                Client Report
            </h2>
        </div>
        <!-- BEGIN: Input -->
        <div class="intro-y box mt-4">

            <div id="input" class="p-5">
                <div class="preview">
                    <form action="<?php echo e(route('reports.update', $report->id)); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <?php if($errors->any()): ?>
                        <div class="alert alert-danger">
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                        <?php endif; ?>
                        <input type="hidden" name="client_id" value="<?php echo e($client->id); ?>">
                        <div class="mt-3">
                            <div class="grid grid-cols-12 gap-6 mt-3">
                                <div class="col-span-12 lg:col-span-6">
                                    <div class="mt-2">
                                        <label class="form-label">Client</label>
                                        <div class="mt-2">
                                            <input id="regular-form-3" name="" type="text" class="form-control" value="<?php echo e($client->sale->business_name); ?>"
                                            placeholder="<?php echo e($client->sale->business_name); ?>" disabled>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-span-12 lg:col-span-6">
                                    <div class="mt-2">
                                        <label for="regular-form-3" class="form-label">Select  Month</label>
                                        <div class="mt-2">
                                            <select data-placeholder="Select Month" class="tom-select w-full" name="month">
                                                <?php if(isset($report->month)): ?>
                                                    <option value="<?php echo e($report->month); ?>" selected><?php echo e($report->month); ?></option>
                                                <?php else: ?>
                                                    <option value="" selected>Please Select</option>
                                                <?php endif; ?>

                                                <option  value="January">January</option>
                                                <option  value="February">February</option>
                                                <option  value="March">March</option>
                                                <option  value="April">April</option>
                                                <option  value="May">May</option>
                                                <option  value="June">June</option>
                                                <option  value="July">July</option>
                                                <option  value="August">August</option>
                                                <option  value="September">September</option>
                                                <option  value="October">October</option>
                                                <option  value="November">November</option>
                                                <option  value="December">December</option>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="mt-3">
                            <div class="grid grid-cols-12 gap-6 mt-3">
                                <div class="col-span-12 lg:col-span-6">
                                    <div class="mt-2">
                                        <label for="regular-form-3" class="form-label">Report Title</label>
                                        <div class="mt-2">
                                            <input id="regular-form-3" name="title" type="text" class="form-control" value="<?php echo e($report->title); ?>"
                                            placeholder="Title" >
                                            
                                        </div>
                                    </div>
                                </div>
                                <div class="col-span-12 lg:col-span-6">
                                    <div class="mt-2">
                                        <label for="regular-form-3" class="form-label">Report Type</label>
                                        <div class="mt-2">
                                            <select data-placeholder="Select Month" class="tom-select w-full" name="type">
                                                <?php if(isset($report->type)): ?>
                                                <option value="<?php echo e($report->type); ?>" selected><?php echo e($report->type); ?></option>
                                                <?php else: ?>
                                                    <option >Please Select</option>
                                                <?php endif; ?>
                                                <option  value="SMM">SMM</option>
                                                <option  value="GMB">GMB</option>
                                                <option  value="LandingPage">LandingPage</option>
                                                <option  value="Website">Website</option>
                                            </select>
                                        </div>
                                    </div>
                                </div>

                            </div>
                        </div>
                        <div class="mt-3">
                            <div class="grid grid-cols-12 gap-6 mt-3">
                                <div class="col-span-12 lg:col-span-6">
                                    <label for="status">Report Status</label>
                                    <div class="mt-2">
                                        <select data-placeholder="Select Month" class="tom-select w-full" id="status" name="status">
                                            <?php if(isset($report->status)): ?>
                                                <option value="<?php echo e($report->status); ?>" selected><?php echo e($report->status); ?></option>
                                            <?php else: ?>
                                                <option >Please Select</option>
                                            <?php endif; ?>
                                            <option  value="Pending">Pending</option>
                                            <option  value="Sent">Sent</option>
                                            <option  value="Approved">Approved</option>
                                            <option  value="Reject">Reject</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-span-12 lg:col-span-6">
                                    <label for="status">File Upload</label>
                                    <div class="mt-2">
                                        <?php if(isset($report->file_path)): ?>
                                            <a href="<?php echo e(asset('reports/' . $report->month . '/' . $report->file_path)); ?>" class="btn btn-primary" target="_blank">View Uploaded File</a>
                                        <?php endif; ?>
                                        <label class="btn btn-primary" >
                                                Upload <?php if(isset($report->file_path)): ?> New <?php endif; ?> Report <input  name="report_file" type="file" name="file" accept=".csv, application/vnd.openxmlformats-officedocument.spreadsheetml.sheet, application/vnd.ms-excel, .pdf"  style="display: none"/>
                                        </label>

                                    </div>
                                </div>

                            </div>
                        </div>

                        <div class="mt-3" id="reject_note" style="display: none">
                            <div class="grid grid-cols-12 gap-6 mt-3">
                                <div class="col-span-12 lg:col-span-12">
                                    <label for="status">Reject Note</label>
                                    <div class="mt-2">
                                        <textarea name="reject_note" id="editor1" ><?php echo e($report->reject_note); ?></textarea>
                                    </div>
                                </div>

                            </div>
                        </div>
                        <div class="mt-3">
                            <div class="grid grid-cols-12 gap-6 mt-3">
                                <div class="col-span-12 lg:col-span-12">
                                    <label for="status">Description</label>
                                    <div class="mt-2">
                                        <textarea name="description" id="editor2" ><?php echo e($report->description); ?></textarea>
                                    </div>
                                </div>

                            </div>
                        </div>

                        


                        <button type="submit" class="btn btn-primary mt-5">Submit</button>
                    </form>
                </div>
            </div>
            <!-- END: Input -->
        </div>
        <!-- END: Content -->
    <?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script>
    $(document).ready(function() {
        $('#status').on('change', function()  {
            var selectedValue = $(this).val();
            if (selectedValue == 'Reject') {
                // alert(selectedValue);
                $('#reject_note').prop('style', 'display: block;');
            } else {
                $('#reject_note').prop('style', 'display: none;');
                // $('#editor1').prop('disabled', false);
            }
        });
    });
</script>
<script>
    CKEDITOR.replace( 'editor1' );
    CKEDITOR.replace( 'editor2' );
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\CRM\resources\views/reports/edit.blade.php ENDPATH**/ ?>